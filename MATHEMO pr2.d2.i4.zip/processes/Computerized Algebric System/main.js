function resolveRecursions(MathAST) {
  return MathAST;
}
