function tokenize(string) {}
