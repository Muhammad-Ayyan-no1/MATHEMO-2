function inturpret(byteCode) {}
