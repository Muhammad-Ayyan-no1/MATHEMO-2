function generateCode(ast) {}
